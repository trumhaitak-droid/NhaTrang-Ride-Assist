plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "vn.khanhhoa.indriveassist"
    compileSdk = 35
    defaultConfig {
        applicationId = "vn.khanhhoa.indriveassist"
        minSdk = 26
        targetSdk = 33
        versionCode = 2
        versionName = "1.1"
    }
}

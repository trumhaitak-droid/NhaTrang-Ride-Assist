# Tài xế tối ưu · Nha Trang (Android)

Gộp 3 phần:
1. **Gợi ý điểm đứng chờ** từ lịch sử cuốc của bạn (heatmap trên Google Maps, bám theo vị trí).
2. **Thuật toán lọc cuốc của bạn** (giá sàn, 3.500đ/km, đón ≤ 5 km, chuyến ≥ 3 km, điểm tối đa 90 → ƯU TIÊN NHẬN / CÂN NHẮC / BỎ QUA). Chỉnh được trong tab Cài đặt.
3. **Hộp nổi** hiện trên Grab/inDrive: kết quả phân tích, gợi ý điểm đứng, nút Có khách / Đã trả khách.

Chỉ đề xuất — không tự nhận cuốc, không bấm thay tài xế.

## Build APK
1. Lấy Google Maps API key: console.cloud.google.com → bật **Maps SDK for Android** → tạo key.
2. Android Studio: tạo `local.properties` với dòng `MAPS_API_KEY=key_cua_ban` → Open → Sync → Build → Build APK(s).
   Hoặc GitHub: đẩy project lên repo (kèm thư mục `.github`), thêm secret `MAPS_API_KEY`, tab Actions → Build Android APK → Run workflow → tải artifact `tai-xe-toi-uu-debug`.
3. Cài `app-debug.apk` lên điện thoại (cho phép nguồn không xác định).

## Cách dùng
1. Tab **Cài đặt** → Cấp quyền hộp nổi (một lần). Kiểm tra bộ lọc.
2. Tab **Bản đồ** → **Bắt đầu ca** (cấp quyền vị trí). Hộp nổi tự hiện.
3. Có cuốc: nhập giá/km vào hộp nổi → Phân tích. Đón được khách: bấm **CÓ KHÁCH**; trả khách xong: **ĐÃ TRẢ KHÁCH**.
4. Sau vài ngày ghi cuốc, gợi ý điểm đứng sẽ sát dần.

## Đọc màn hình (tùy chọn, mặc định tắt)
Bật trong Cài đặt Trợ năng → "Trợ lý lọc cuốc". Chỉ đọc chữ của app Grab/inDrive để tự điền giá/km; bỏ qua mọi app khác.
Hãng có thể không cho phép công cụ bên thứ ba — nếu lo ngại, dùng nhập tay.
Thứ tự hai số km đọc được có thể không khớp km đón/km chở: luôn đối chiếu màn hình gốc.

## Còn để ngỏ
- 10 điểm "nhu cầu điểm đến" vẫn để trống (chưa có tọa độ điểm đến + dữ liệu thật).
- Chưa kiểm thử trên máy thật; chưa tính đường bộ (Routes API).

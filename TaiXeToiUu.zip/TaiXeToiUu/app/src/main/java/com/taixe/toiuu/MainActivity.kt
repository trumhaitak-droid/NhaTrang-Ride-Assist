package com.taixe.toiuu

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Trips.load(this)
        setContent { MaterialTheme { Surface { AppScreen(vm) } } }
    }
}

private fun hasLocationPermission(c: Context) =
    ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

private fun startServices(c: Context) {
    ContextCompat.startForegroundService(c, Intent(c, TrackingService::class.java))
    if (Settings.canDrawOverlays(c)) {
        ContextCompat.startForegroundService(c, Intent(c, FloatingService::class.java))
    }
}

private fun stopServices(c: Context) {
    c.startService(TrackingService.stopIntent(c))
    c.stopService(Intent(c, FloatingService::class.java))
}

@Composable
fun AppScreen(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Bản đồ") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Cài đặt") })
        }
        if (tab == 0) MapTab(vm) else SettingsTab(vm)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapTab(vm: MainViewModel) {
    val ctx = LocalContext.current
    val loc by Hub.location.collectAsState()
    val sug by Hub.suggestions.collectAsState()
    val heat by Hub.heat.collectAsState()
    val running by Hub.running.collectAsState()
    val onTrip by Hub.onTrip.collectAsState()
    val platform by Hub.platform.collectAsState()
    val count by vm.rideCount.collectAsState()
    var granted by remember { mutableStateOf(hasLocationPermission(ctx)) }

    val perms = buildList {
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasLocationPermission(ctx)
        if (granted) {
            vm.startShift()
            startServices(ctx)
        }
    }

    Column(Modifier.fillMaxSize()) {
        MapPane(loc, heat, sug.firstOrNull(), granted, Modifier.weight(1f).fillMaxWidth())

        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                sug.firstOrNull()?.text()
                    ?: "Chưa đủ dữ liệu cho khung giờ này. Hãy ghi các cuốc bạn nhận để app học (đã ghi: $count cuốc).",
                style = MaterialTheme.typography.bodyLarge
            )
            sug.drop(1).forEach {
                Text("• Phương án: ${"%.1f".format(it.distKm)} km hướng ${it.bearing} (${it.rides} cuốc)",
                    style = MaterialTheme.typography.bodySmall)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("GRAB" to "Grab", "XANH_SM" to "Xanh SM", "INDRIVE" to "inDrive", "KHAC" to "Khác").forEach { (k, label) ->
                    FilterChip(selected = platform == k, onClick = { Hub.platform.value = k }, label = { Text(label) })
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { if (running) stopServices(ctx) else launcher.launch(perms) },
                    modifier = Modifier.weight(1f)
                ) { Text(if (running) "Kết thúc ca" else "Bắt đầu ca") }

                Button(
                    onClick = { if (onTrip) vm.dropoff() else vm.pickup() },
                    enabled = running && loc != null,
                    modifier = Modifier.weight(1f)
                ) { Text(if (onTrip) "Đã trả khách" else "Có khách") }
            }
            Text("Đã ghi $count cuốc • Dữ liệu chỉ lưu trên máy bạn.", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun SettingsTab(vm: MainViewModel) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsState()
    var floor by remember(s) { mutableStateOf(s.minFare.toString()) }
    var cost by remember(s) { mutableStateOf(s.costPerKm.toInt().toString()) }
    var pickup by remember(s) { mutableStateOf(s.maxPickupKm.toString()) }
    var trip by remember(s) { mutableStateOf(s.minTripKm.toString()) }
    var margin by remember(s) { mutableStateOf(s.marginPct.toString()) }
    var saved by remember { mutableStateOf(false) }
    val num = KeyboardOptions(keyboardType = KeyboardType.Decimal)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Bộ lọc cuốc", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(floor, { floor = it }, label = { Text("Giá sàn (đ)") }, singleLine = true, keyboardOptions = num, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(cost, { cost = it }, label = { Text("Chi phí vận hành (đ/km)") }, singleLine = true, keyboardOptions = num, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pickup, { pickup = it }, label = { Text("Đón tối đa (km)") }, singleLine = true, keyboardOptions = num, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(trip, { trip = it }, label = { Text("Chở tối thiểu (km)") }, singleLine = true, keyboardOptions = num, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(margin, { margin = it }, label = { Text("Biên lợi nhuận mục tiêu (%)") }, singleLine = true, keyboardOptions = num, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            vm.saveSettings(
                FilterSettings(
                    floor.toLongOrNull() ?: 80_000L,
                    cost.replace(',', '.').toDoubleOrNull() ?: 3_500.0,
                    pickup.replace(',', '.').toDoubleOrNull() ?: 5.0,
                    trip.replace(',', '.').toDoubleOrNull() ?: 3.0,
                    margin.toIntOrNull() ?: 20
                )
            )
            saved = true
        }) { Text(if (saved) "Đã lưu ✔" else "Lưu bộ lọc") }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        Text("Hộp nổi & đọc màn hình", style = MaterialTheme.typography.titleMedium)
        Text("Hộp nổi tự hiện khi bấm Bắt đầu ca (cần quyền hiển thị trên ứng dụng khác).", style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
        }) { Text("Cấp quyền hộp nổi") }

        Text(
            "Tùy chọn: cho app ĐỌC chữ trên màn hình Grab/inDrive để tự điền giá và km. Chỉ đọc, không bấm thay bạn, " +
                "không đọc app khác. Lưu ý: hãng có thể không cho phép công cụ bên thứ ba; nếu lo ngại, cứ nhập tay trong hộp nổi.",
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
            Text("Mở cài đặt Trợ năng")
        }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        OutlinedButton(onClick = { vm.clearAll() }) { Text("Xóa toàn bộ lịch sử cuốc đã ghi") }
    }
}

@Composable
fun MapPane(
    loc: android.location.Location?,
    heat: Map<Pair<Int, Int>, Double>,
    top: Suggestion?,
    hasPerm: Boolean,
    modifier: Modifier
) {
    val camera = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(12.2388, 109.1967), 14f) // Nha Trang
    }
    var follow by remember { mutableStateOf(true) }

    LaunchedEffect(loc, follow) {
        val l = loc
        if (follow && l != null) {
            camera.animate(CameraUpdateFactory.newLatLng(LatLng(l.latitude, l.longitude)))
        }
    }
    LaunchedEffect(camera.isMoving) {
        if (camera.isMoving && camera.cameraMoveStartedReason == CameraMoveStartedReason.GESTURE) follow = false
    }

    val s = Grid.STEP
    fun rect(ix: Int, iy: Int) = listOf(
        LatLng(ix * s, iy * s), LatLng((ix + 1) * s, iy * s),
        LatLng((ix + 1) * s, (iy + 1) * s), LatLng(ix * s, (iy + 1) * s)
    )
    val max = heat.values.maxOrNull() ?: 0.0

    Box(modifier) {
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = camera,
            properties = MapProperties(isMyLocationEnabled = hasPerm),
            uiSettings = MapUiSettings(myLocationButtonEnabled = false, zoomControlsEnabled = false)
        ) {
            for ((k, w) in heat) {
                val a = (0.15f + 0.6f * (w / max).toFloat()).coerceIn(0f, 0.8f)
                Polygon(
                    points = rect(k.first, k.second),
                    fillColor = Color(1f, 0.34f, 0.13f, a),
                    strokeColor = Color.Transparent,
                    strokeWidth = 0f
                )
            }
            if (top != null) {
                Polygon(
                    points = rect(top.ix, top.iy),
                    fillColor = Color.Transparent,
                    strokeColor = Color(0xFF00A03C),
                    strokeWidth = 8f
                )
            }
        }
        FilledTonalButton(
            onClick = { follow = !follow },
            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
        ) { Text(if (follow) "Đang bám vị trí" else "Bám vị trí") }
    }
}

package com.taixe.toiuu

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

/** Giá trị đọc từ màn hình chỉ là gợi ý, tài xế phải kiểm tra lại. */
data class RideCandidate(
    val fare: Long? = null,
    val pickupKm: Double? = null,
    val tripKm: Double? = null,
    val extraFee: Long = 0L,
    val rawText: String = "",
    val sourceApp: String = "Ứng dụng khác",
    val confidence: String = "THẤP"
)

data class RideDecision(
    val title: String,
    val score: Int?,
    val maxScore: Int,
    val cost: Long?,
    val target: Long?,
    val profit: Long?,
    val detail: String
)

object RideTextParser {
    private val currencyRegex = Regex("(?i)(\\d{1,3}(?:[.,]\\d{3})+|\\d{5,7})\\s*(?:đ|₫|vnd)")
    private val kmRegex = Regex("(?i)(\\d+(?:[.,]\\d+)?)\\s*km\\b")

    fun parse(text: String, packageName: String): RideCandidate {
        val fare = currencyRegex.findAll(text).mapNotNull { m ->
            m.groupValues[1].replace(".", "").replace(",", "").toLongOrNull()
        }.firstOrNull { it in 10_000L..10_000_000L }
        val kms = kmRegex.findAll(text).mapNotNull {
            it.groupValues[1].replace(',', '.').toDoubleOrNull()
        }.filter { it in 0.0..1000.0 }.toList()
        val app = when {
            packageName.contains("grab", true) -> "Grab"
            packageName.contains("indri", true) -> "inDrive"
            else -> "Ứng dụng khác"
        }
        // Chỉ tự điền km khi thấy ít nhất hai giá trị km.
        val pickup = if (kms.size >= 2) kms.first() else null
        val trip = if (kms.size >= 2) kms.last() else null
        val confidence = when {
            fare != null && pickup != null && trip != null -> "TRUNG BÌNH · CẦN KIỂM TRA"
            fare != null || kms.isNotEmpty() -> "THẤP · THIẾU DỮ LIỆU"
            else -> "KHÔNG ĐỦ DỮ LIỆU"
        }
        return RideCandidate(fare, pickup, trip, 0L, text.take(1200), app, confidence)
    }
}

object RideScoring {
    private val money = NumberFormat.getNumberInstance(Locale("vi", "VN"))

    /**
     * Điểm: lợi nhuận 40 + hiệu quả lãi/km 30 + độ gần điểm đón 20 = tối đa 90.
     * [demandScore] (0..10) chỉ được cộng khi có dữ liệu thật về nhu cầu điểm đến; mặc định để trống.
     */
    fun analyze(ride: RideCandidate, s: FilterSettings = FilterSettings(), demandScore: Int? = null): RideDecision {
        val maxScore = if (demandScore != null) 100 else 90
        val fare = ride.fare
        val pickup = ride.pickupKm
        val trip = ride.tripKm
        if (fare == null || pickup == null || trip == null) {
            return RideDecision("CẦN KIỂM TRA THỦ CÔNG", null, maxScore, null, null, null,
                "Chưa đọc đủ giá + km đón + km chở. Không tự suy đoán số liệu. ${ride.confidence}")
        }
        if (pickup > s.maxPickupKm) return RideDecision("BỎ QUA", 0, maxScore, null, null, null,
            "Điểm đón $pickup km, vượt giới hạn ${s.maxPickupKm} km.")
        if (trip < s.minTripKm) return RideDecision("BỎ QUA / KIỂM TRA", 0, maxScore, null, null, null,
            "Quãng đường chở khách dưới ${s.minTripKm} km theo cấu hình.")
        if (fare < s.minFare) return RideDecision("BỎ QUA / TRẢ GIÁ", 0, maxScore, null, null, null,
            "Giá ${money.format(fare)}đ thấp hơn giá sàn ${money.format(s.minFare)}đ.")

        val totalKm = pickup + trip
        val cost = (s.costPerKm * totalKm).toLong() + ride.extraFee
        val m = s.marginPct.coerceIn(0, 80) / 100.0
        val target = ceil(max(s.minFare.toDouble(), cost / (1 - m)) / 5000.0).toLong() * 5000L
        val profit = fare - cost
        val margin = if (fare > 0) profit.toDouble() / fare else 0.0
        val profitScore = (margin.coerceIn(0.0, 0.45) / 0.45 * 40).toInt()
        val perKmScore = ((profit.toDouble() / totalKm).coerceIn(0.0, 12000.0) / 12000.0 * 30).toInt()
        val pickupScore = when {
            pickup <= 1.0 -> 20
            pickup <= 2.0 -> 17
            pickup <= 3.0 -> 13
            pickup <= 4.0 -> 8
            else -> 4
        }
        val score = (profitScore + perKmScore + pickupScore + (demandScore ?: 0)).coerceIn(0, maxScore)
        val title = when {
            fare >= target && score >= 65 -> "ƯU TIÊN NHẬN"
            score >= 45 -> "CÂN NHẮC"
            else -> "BỎ QUA / TRẢ GIÁ"
        }
        val demandNote = if (demandScore == null) " (10 điểm nhu cầu điểm đến chưa chấm vì chưa có dữ liệu)" else ""
        val detail = "Điểm $score/$maxScore$demandNote. " +
            "Chi phí ước tính ${money.format(cost)}đ; lãi ${money.format(profit)}đ; giá mục tiêu ${money.format(target)}đ. " +
            "Chưa gồm phí nền tảng, cầu đường, chờ và chiều về rỗng. Kiểm tra lại số liệu trên ứng dụng trước khi quyết định."
        return RideDecision(title, score, maxScore, cost, target, profit, detail)
    }
}

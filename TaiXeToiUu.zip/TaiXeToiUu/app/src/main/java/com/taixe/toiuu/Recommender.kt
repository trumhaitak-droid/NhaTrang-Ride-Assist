package com.taixe.toiuu

import java.util.Calendar
import kotlin.math.*

/** Lưới ô vuông ~450 m (0.004 độ). */
object Grid {
    const val STEP = 0.004
    fun idx(v: Double) = floor(v / STEP).toInt()
    fun center(i: Int) = (i + 0.5) * STEP
}

data class Suggestion(
    val ix: Int, val iy: Int,
    val lat: Double, val lng: Double,
    val distKm: Double, val score: Double,
    val rides: Int, val avgWaitMin: Int?,
    val stay: Boolean, val bearing: String
) {
    fun text(): String {
        val wait = avgWaitMin?.let { ", chờ TB ~$it phút" } ?: ""
        return if (stay) "✅ Khu vực hiện tại đang tốt – nên đứng đợi tại đây (lịch sử $rides cuốc$wait)."
        else "➡️ Nên di chuyển ${"%.1f".format(distKm)} km về hướng $bearing (lịch sử $rides cuốc$wait)."
    }
}

object Recommender {

    private fun isWeekend(c: Calendar) =
        c.get(Calendar.DAY_OF_WEEK).let { it == Calendar.SATURDAY || it == Calendar.SUNDAY }

    /** Trọng số của 1 cuốc cũ so với thời điểm hiện tại: giống giờ, giống ngày, càng mới càng cao. */
    fun weight(r: Ride, now: Long): Double {
        val cr = Calendar.getInstance().apply { timeInMillis = r.timeMillis }
        val cn = Calendar.getInstance().apply { timeInMillis = now }
        val hr = cr.get(Calendar.HOUR_OF_DAY) + cr.get(Calendar.MINUTE) / 60.0
        val hn = cn.get(Calendar.HOUR_OF_DAY) + cn.get(Calendar.MINUTE) / 60.0
        var dh = abs(hr - hn)
        dh = min(dh, 24 - dh)
        if (dh > 1.5) return 0.0
        val timeW = 1.0 - dh / 3.0
        val dayW = when {
            cr.get(Calendar.DAY_OF_WEEK) == cn.get(Calendar.DAY_OF_WEEK) -> 1.0
            isWeekend(cr) == isWeekend(cn) -> 0.6
            else -> 0.25
        }
        val ageDays = (now - r.timeMillis) / 86_400_000.0
        return timeW * dayW * exp(-ageDays / 45.0)
    }

    fun heat(rides: List<Ride>, now: Long): Map<Pair<Int, Int>, Double> {
        val m = HashMap<Pair<Int, Int>, Double>()
        for (r in rides) {
            val w = weight(r, now)
            if (w <= 0) continue
            val k = Grid.idx(r.lat) to Grid.idx(r.lng)
            m[k] = (m[k] ?: 0.0) + w
        }
        return m
    }

    private class Agg { var w = 0.0; var n = 0; var waitSum = 0.0; var waitW = 0.0 }

    fun suggest(rides: List<Ride>, lat: Double, lng: Double, now: Long, maxKm: Double = 4.0): List<Suggestion> {
        val cells = HashMap<Pair<Int, Int>, Agg>()
        for (r in rides) {
            val w = weight(r, now)
            if (w <= 0) continue
            val a = cells.getOrPut(Grid.idx(r.lat) to Grid.idx(r.lng)) { Agg() }
            a.w += w; a.n++
            if (r.waitSeconds > 0) { a.waitSum += r.waitSeconds * w; a.waitW += w }
        }
        if (cells.isEmpty()) return emptyList()

        val here = Grid.idx(lat) to Grid.idx(lng)
        val list = cells.mapNotNull { (k, a) ->
            val cLat = Grid.center(k.first); val cLng = Grid.center(k.second)
            val d = haversineKm(lat, lng, cLat, cLng)
            if (d > maxKm) return@mapNotNull null
            Suggestion(
                k.first, k.second, cLat, cLng, d,
                a.w / (1 + 0.5 * d), a.n,
                if (a.waitW > 0) (a.waitSum / a.waitW / 60).roundToInt() else null,
                false, bearing(lat, lng, cLat, cLng)
            )
        }.sortedByDescending { it.score }.take(3)
        if (list.isEmpty()) return emptyList()

        val curScore = cells[here]?.w ?: 0.0
        val stay = (list[0].ix to list[0].iy) == here || curScore >= 0.7 * list[0].score
        return if (stay && cells[here] != null) {
            val a = cells[here]!!
            val cur = Suggestion(here.first, here.second, lat, lng, 0.0, curScore, a.n,
                if (a.waitW > 0) (a.waitSum / a.waitW / 60).roundToInt() else null, true, "")
            listOf(cur) + list.filter { (it.ix to it.iy) != here }.take(2)
        } else list
    }

    fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(a))
    }

    private fun bearing(lat1: Double, lon1: Double, lat2: Double, lon2: Double): String {
        val p1 = Math.toRadians(lat1); val p2 = Math.toRadians(lat2)
        val dl = Math.toRadians(lon2 - lon1)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        val b = (Math.toDegrees(atan2(y, x)) + 360) % 360
        val names = arrayOf("Bắc", "Đông Bắc", "Đông", "Đông Nam", "Nam", "Tây Nam", "Tây", "Tây Bắc")
        return names[((b + 22.5) / 45).toInt() % 8]
    }
}

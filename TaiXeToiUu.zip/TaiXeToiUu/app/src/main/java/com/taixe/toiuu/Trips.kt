package com.taixe.toiuu

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Ghi cuốc: dùng chung cho giao diện chính và hộp nổi. */
object Trips {
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("state", 0)

    fun load(c: Context) {
        Hub.onTrip.value = prefs(c).getBoolean("onTrip", false)
    }

    fun startShift(c: Context) {
        prefs(c).edit().putLong("lastFree", System.currentTimeMillis()).apply()
    }

    /** Vừa đón được khách: ghi cuốc tại vị trí hiện tại + thời gian đã chờ. */
    fun pickup(c: Context): Boolean {
        val loc = Hub.location.value ?: return false
        val p = prefs(c)
        val now = System.currentTimeMillis()
        val wait = ((now - p.getLong("lastFree", now)) / 1000).coerceIn(0, 7200)
        val platform = Hub.platform.value
        val app = c.applicationContext
        io.launch {
            AppDb.get(app).rideDao().insert(
                Ride(lat = loc.latitude, lng = loc.longitude, timeMillis = now, platform = platform, waitSeconds = wait)
            )
        }
        p.edit().putBoolean("onTrip", true).apply()
        Hub.onTrip.value = true
        return true
    }

    /** Trả khách xong: bắt đầu tính thời gian chờ cuốc kế tiếp. */
    fun dropoff(c: Context) {
        prefs(c).edit().putBoolean("onTrip", false).putLong("lastFree", System.currentTimeMillis()).apply()
        Hub.onTrip.value = false
    }
}

package com.taixe.toiuu

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * TÙY CHỌN (mặc định tắt trong Cài đặt Android). Chỉ ĐỌC chữ hiển thị của app Grab / inDrive,
 * không bấm, không gửi thao tác. Bỏ qua mọi ứng dụng khác để bảo vệ quyền riêng tư.
 */
class RideAccessibilityService : AccessibilityService() {
    private var lastText = ""
    private var lastSentAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (!pkg.contains("grab", true) && !pkg.contains("indri", true)) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastSentAt < 900) return
        val root = rootInActiveWindow ?: return
        val parts = ArrayList<String>()
        collectText(root, parts, 0)
        val text = parts.distinct().joinToString(" · ").trim()
        if (text.length < 12 || text == lastText) return
        lastText = text
        lastSentAt = now
        Hub.screen.tryEmit(ScreenText(text.take(6000), pkg))
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 18 || out.size > 250) return
        node.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until node.childCount) collectText(node.getChild(i), out, depth + 1)
    }

    override fun onInterrupt() = Unit
}

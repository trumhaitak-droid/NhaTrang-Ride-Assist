package com.taixe.toiuu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.location.Location
import android.os.IBinder
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Hộp nổi: hiện gợi ý điểm đứng, phân tích cuốc (thuật toán lọc của bạn) và nút ghi cuốc.
 * Chỉ đề xuất — không tự nhận cuốc, không bấm thay tài xế.
 */
class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams

    private var resultView: TextView? = null
    private var recoView: TextView? = null
    private var screenView: TextView? = null
    private var gpsView: TextView? = null
    private var recordBtn: Button? = null
    private var fareInput: EditText? = null
    private var pickupInput: EditText? = null
    private var tripInput: EditText? = null
    private var extraInput: EditText? = null
    private var focusable = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        try {
            showPanel()
        } catch (e: Exception) {
            stopSelf()
            return
        }
        scope.launch { Hub.location.collect { it?.let(::updateGps) } }
        scope.launch {
            Hub.suggestions.collect { s ->
                recoView?.text = s.firstOrNull()?.text() ?: "Chưa đủ dữ liệu khu vực – hãy ghi các cuốc bạn nhận."
            }
        }
        scope.launch {
            Hub.onTrip.collect { t ->
                recordBtn?.text = if (t) "ĐÃ TRẢ KHÁCH" else "CÓ KHÁCH (ghi cuốc)"
            }
        }
        scope.launch { Hub.screen.collect(::onScreen) }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("float", "Hộp nổi", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = NotificationCompat.Builder(this, "float")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Hộp nổi đang bật")
            .setContentText("Chỉ phân tích và đề xuất, không tự nhận cuốc")
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 41, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
    }

    private fun updateGps(l: Location) {
        val (z, d) = Zones.nearest(l.latitude, l.longitude)
        gpsView?.text = "GPS ${"%.5f".format(Locale.US, l.latitude)}, ${"%.5f".format(Locale.US, l.longitude)}" +
            " · gần ${z.name} (${"%.1f".format(Locale.US, d)} km)"
    }

    private fun onScreen(s: ScreenText) {
        val t = s.text
        val hasHints = t.contains("km", true) || t.contains("đ", true) || t.contains("₫") || t.contains("VND", true)
        if (!hasHints) return
        val c = RideTextParser.parse(t, s.pkg)
        when (c.sourceApp) {
            "Grab" -> Hub.platform.value = "GRAB"
            "inDrive" -> Hub.platform.value = "INDRIVE"
        }
        c.fare?.let { fareInput?.setText(it.toString()) }
        c.pickupKm?.let { pickupInput?.setText(it.toString()) }
        c.tripKm?.let { tripInput?.setText(it.toString()) }
        screenView?.text = "Đã đọc từ ${c.sourceApp}: ${c.confidence}. Kiểm tra các ô số liệu trước khi dùng."
        if (c.fare != null && c.pickupKm != null && c.tripKm != null) {
            showDecision(RideScoring.analyze(c, SettingsStore.load(this)))
        } else {
            resultView?.text = "CHƯA ĐỦ DỮ LIỆU — kiểm tra hoặc nhập bổ sung giá, km đón và km chở."
            resultView?.setTextColor(Color.rgb(138, 90, 0))
        }
    }

    private fun analyzeManual() {
        val fare = fareInput?.text?.toString()?.replace(".", "")?.replace(",", "")?.toLongOrNull()
        val pickup = pickupInput?.text?.toString()?.replace(',', '.')?.toDoubleOrNull()
        val trip = tripInput?.text?.toString()?.replace(',', '.')?.toDoubleOrNull()
        val extra = extraInput?.text?.toString()?.replace(".", "")?.replace(",", "")?.toLongOrNull() ?: 0L
        val c = RideCandidate(fare, pickup, trip, extra, confidence = "NHẬP / XÁC NHẬN THỦ CÔNG")
        showDecision(RideScoring.analyze(c, SettingsStore.load(this)))
        setFocusable(false)
    }

    private fun showDecision(d: RideDecision) {
        resultView?.text = buildString {
            append(d.title)
            d.score?.let { append(" · $it/${d.maxScore}") }
            append("\n${d.detail}")
        }
        resultView?.setTextColor(
            when {
                d.title.contains("ƯU TIÊN") -> Color.rgb(0, 115, 67)
                d.title.contains("BỎ QUA") -> Color.rgb(180, 35, 24)
                else -> Color.rgb(138, 90, 0)
            }
        )
    }

    /** Mặc định hộp nổi KHÔNG chiếm tiêu điểm để không cản trở app Grab/inDrive; chỉ bật khi gõ số. */
    private fun setFocusable(on: Boolean) {
        val p = panel ?: return
        if (focusable == on) return
        focusable = on
        params.flags = if (on) {
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        try { wm.updateViewLayout(p, params) } catch (_: Exception) {}
    }

    private fun field(label: String): EditText = EditText(this).apply {
        hint = label
        textSize = 13f
        isSingleLine = true
        setPadding(8, 2, 8, 2)
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) setFocusable(true)
            false
        }
    }

    private fun showPanel() {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(248, 251, 249))
            elevation = dp(10).toFloat()
        }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "TRỢ LÝ CUỐC · kéo để di chuyển"
            textSize = 13f
            setTextColor(Color.rgb(18, 107, 80))
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val toggle = Button(this).apply {
            text = "Thu gọn"
            textSize = 11f
            setOnClickListener {
                val show = body.visibility != View.VISIBLE
                body.visibility = if (show) View.VISIBLE else View.GONE
                text = if (show) "Thu gọn" else "Mở rộng"
            }
        }
        val close = Button(this).apply { text = "Tắt"; textSize = 11f; setOnClickListener { stopSelf() } }
        header.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        header.addView(toggle, LinearLayout.LayoutParams(dp(82), dp(44)))
        header.addView(close, LinearLayout.LayoutParams(dp(54), dp(44)))
        card.addView(header)

        resultView = TextView(this).apply {
            text = "Chờ đọc cuốc hoặc nhập số liệu để phân tích."
            textSize = 13f
            setTextColor(Color.BLACK)
            setPadding(0, dp(6), 0, dp(6))
        }
        card.addView(resultView)

        recoView = TextView(this).apply {
            text = "Đang tính gợi ý điểm đứng…"
            textSize = 12f
            setTextColor(Color.rgb(18, 107, 80))
            setPadding(0, 0, 0, dp(6))
        }
        card.addView(recoView)

        recordBtn = Button(this).apply {
            text = "CÓ KHÁCH (ghi cuốc)"
            setOnClickListener {
                if (Hub.onTrip.value) Trips.dropoff(this@FloatingService)
                else if (!Trips.pickup(this@FloatingService)) {
                    Toast.makeText(this@FloatingService, "Chưa có vị trí GPS – hãy bấm Bắt đầu ca trong app", Toast.LENGTH_LONG).show()
                }
            }
        }
        card.addView(recordBtn)

        screenView = TextView(this).apply {
            text = "Nhập tay hoặc bật đọc màn hình (tùy chọn) để tự điền."
            textSize = 11f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(6), 0, dp(4))
        }
        gpsView = TextView(this).apply {
            text = "GPS: đang chờ vị trí…"
            textSize = 10f
            setTextColor(Color.GRAY)
            setPadding(0, 0, 0, dp(4))
        }
        val s = SettingsStore.load(this)
        val cfg = TextView(this).apply {
            text = "Sàn ${s.minFare / 1000}k · ${s.costPerKm.toInt()}đ/km · đón ≤ ${s.maxPickupKm} km · chuyến ≥ ${s.minTripKm} km"
            textSize = 11f
            setTextColor(Color.DKGRAY)
        }
        fareInput = field("Giá cuốc (đ)")
        pickupInput = field("Km đến điểm đón")
        tripInput = field("Km chở khách")
        extraInput = field("Phí phát sinh (đ, tùy chọn)")
        val analyze = Button(this).apply { text = "PHÂN TÍCH / KIỂM TRA CUỐC"; setOnClickListener { analyzeManual() } }
        val foot = TextView(this).apply {
            text = "Chỉ đề xuất, không tự nhận. Số đọc tự động có thể sai — luôn đối chiếu màn hình gốc."
            textSize = 10f
            setTextColor(Color.GRAY)
        }
        listOf(screenView!!, gpsView!!, cfg, fareInput!!, pickupInput!!, tripInput!!, extraInput!!, analyze, foot)
            .forEach { body.addView(it) }
        card.addView(body)

        val scroll = ScrollView(this).apply { addView(card) }
        params = WindowManager.LayoutParams(
            dp(310), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(8); y = dp(90) }
        panel = scroll
        wm.addView(scroll, params)

        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var wx = 0; var wy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; wx = params.x; wy = params.y; return true }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = (wx - (e.rawX - sx).toInt()).coerceAtLeast(0)
                        params.y = (wy + (e.rawY - sy).toInt()).coerceAtLeast(0)
                        wm.updateViewLayout(scroll, params)
                        return true
                    }
                }
                return false
            }
        })
    }

    override fun onDestroy() {
        scope.cancel()
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

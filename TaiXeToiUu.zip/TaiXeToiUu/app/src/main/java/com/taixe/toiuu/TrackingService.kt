package com.taixe.toiuu

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.android.gms.location.*
import kotlinx.coroutines.*

/** Chạy nền: theo dõi vị trí, tính gợi ý điểm đứng, cập nhật thông báo. */
class TrackingService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var client: FusedLocationProviderClient

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.lastLocation?.let { onLoc(it) }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("MissingPermission")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            client.removeLocationUpdates(callback)
            Hub.running.value = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        ServiceCompat.startForeground(
            this, NOTI_ID, buildNotification("Đang theo dõi vị trí…"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        )
        client = LocationServices.getFusedLocationProviderClient(this)
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10_000L)
            .setMinUpdateDistanceMeters(15f).build()
        client.requestLocationUpdates(req, callback, mainLooper)
        Hub.running.value = true
        return START_STICKY
    }

    private fun onLoc(loc: Location) {
        Hub.location.value = loc
        scope.launch {
            val rides = AppDb.get(this@TrackingService).rideDao().all()
            val now = System.currentTimeMillis()
            val sug = Recommender.suggest(rides, loc.latitude, loc.longitude, now)
            Hub.suggestions.value = sug
            Hub.heat.value = Recommender.heat(rides, now)
            val text = sug.firstOrNull()?.text() ?: "Chưa đủ dữ liệu – hãy ghi các cuốc bạn nhận."
            getSystemService(NotificationManager::class.java).notify(NOTI_ID, buildNotification(text))
        }
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Tài xế tối ưu")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .build()
    }

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL, "Theo dõi vị trí", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    override fun onDestroy() {
        scope.cancel()
        Hub.running.value = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.taixe.toiuu.STOP"
        private const val CHANNEL = "tracking"
        private const val NOTI_ID = 1
        fun stopIntent(c: Context) = Intent(c, TrackingService::class.java).setAction(ACTION_STOP)
    }
}

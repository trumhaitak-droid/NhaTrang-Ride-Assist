package com.taixe.toiuu

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "rides")
data class Ride(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lat: Double,
    val lng: Double,
    val timeMillis: Long,
    val platform: String,
    val waitSeconds: Long
)

@Dao
interface RideDao {
    @Insert suspend fun insert(r: Ride)
    @Query("SELECT * FROM rides") suspend fun all(): List<Ride>
    @Query("SELECT COUNT(*) FROM rides") fun count(): Flow<Int>
    @Query("DELETE FROM rides") suspend fun clear()
}

@Database(entities = [Ride::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun rideDao(): RideDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "rides.db")
                .build().also { inst = it }
        }
    }
}

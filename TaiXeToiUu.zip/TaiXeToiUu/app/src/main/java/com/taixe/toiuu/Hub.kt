package com.taixe.toiuu

import android.location.Location
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow

data class ScreenText(val text: String, val pkg: String)

/** Trạng thái dùng chung giữa các Service (chạy nền, hộp nổi) và giao diện. */
object Hub {
    val location = MutableStateFlow<Location?>(null)
    val suggestions = MutableStateFlow<List<Suggestion>>(emptyList())
    val heat = MutableStateFlow<Map<Pair<Int, Int>, Double>>(emptyMap())
    val running = MutableStateFlow(false)
    val onTrip = MutableStateFlow(false)
    val platform = MutableStateFlow("GRAB")
    val screen = MutableSharedFlow<ScreenText>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)
}

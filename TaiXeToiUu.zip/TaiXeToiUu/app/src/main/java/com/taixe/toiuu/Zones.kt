package com.taixe.toiuu

/** Các mốc tham chiếu Nha Trang (để hiển thị khu vực gần nhất). */
object Zones {
    data class Zone(val name: String, val lat: Double, val lon: Double)

    val list = listOf(
        Zone("Trung tâm / Quảng trường 2-4", 12.2388, 109.1967),
        Zone("Ga Nha Trang", 12.2451, 109.1907),
        Zone("Chợ Đầm", 12.2527, 109.1902),
        Zone("Vĩnh Hải", 12.2730, 109.2010),
        Zone("Khu Trần Phú", 12.2250, 109.2020)
    )

    fun nearest(lat: Double, lon: Double): Pair<Zone, Double> {
        val z = list.minByOrNull { Recommender.haversineKm(lat, lon, it.lat, it.lon) }!!
        return z to Recommender.haversineKm(lat, lon, z.lat, z.lon)
    }
}

package com.taixe.toiuu

import android.content.Context

/** Cấu hình bộ lọc cuốc (mặc định theo thuật toán của bạn). */
data class FilterSettings(
    val minFare: Long = 80_000L,
    val costPerKm: Double = 3_500.0,
    val maxPickupKm: Double = 5.0,
    val minTripKm: Double = 3.0,
    val marginPct: Int = 20
)

object SettingsStore {
    fun load(c: Context): FilterSettings {
        val p = c.applicationContext.getSharedPreferences("filter", 0)
        return FilterSettings(
            p.getLong("minFare", 80_000L),
            p.getFloat("cost", 3_500f).toDouble(),
            p.getFloat("maxPickup", 5f).toDouble(),
            p.getFloat("minTrip", 3f).toDouble(),
            p.getInt("margin", 20)
        )
    }

    fun save(c: Context, s: FilterSettings) {
        c.applicationContext.getSharedPreferences("filter", 0).edit()
            .putLong("minFare", s.minFare)
            .putFloat("cost", s.costPerKm.toFloat())
            .putFloat("maxPickup", s.maxPickupKm.toFloat())
            .putFloat("minTrip", s.minTripKm.toFloat())
            .putInt("margin", s.marginPct)
            .apply()
    }
}

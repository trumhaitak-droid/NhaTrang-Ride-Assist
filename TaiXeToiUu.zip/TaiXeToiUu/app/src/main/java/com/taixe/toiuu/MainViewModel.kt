package com.taixe.toiuu

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app
    private val dao = AppDb.get(app).rideDao()

    val rideCount = dao.count().stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val settings = MutableStateFlow(SettingsStore.load(app))

    fun startShift() = Trips.startShift(ctx)
    fun pickup() = Trips.pickup(ctx)
    fun dropoff() = Trips.dropoff(ctx)

    fun saveSettings(s: FilterSettings) {
        SettingsStore.save(ctx, s)
        settings.value = s
    }

    fun clearAll() = viewModelScope.launch(Dispatchers.IO) { dao.clear() }
}

# Trợ lý lọc cuốc Nha Trang — Android source

Dự án Android Kotlin kế thừa bộ `IndriveFloatingAssist` trước đây và mở rộng theo cấu hình đã thống nhất:

- Hỗ trợ quan sát màn hình khi tài xế đang dùng Grab hoặc inDrive (qua Android Accessibility Service).
- Cửa sổ nổi đọc được giá/km khi nội dung giao diện cung cấp dữ liệu; tự điền vào ô và phân tích. Các trường chưa đọc chắc chắn để trống, không tự đoán.
- GPS dùng `LocationManager` của Android; hiển thị tọa độ và mốc gần nhất trong nhóm mốc tham chiếu Nha Trang.
- Chỉ đề xuất ƯU TIÊN NHẬN / CÂN NHẮC / BỎ QUA. Không tự bấm nhận, không gửi giá, không tương tác thay tài xế.

## Cấu hình bộ lọc

- Giá sàn: 80.000đ.
- Chi phí vận hành: 3.500đ/km × (km đón + km chở).
- Khoảng cách đón tối đa: 5 km.
- Quãng đường chở tối thiểu: 3 km (ngưỡng thử nghiệm đã dùng trong bản thiết kế).
- Giá mục tiêu: làm tròn lên 5.000đ của `max(80.000, chi phí / 0,8)` — tương ứng biên lợi nhuận mục tiêu 20% trên doanh thu.
- Điểm tối đa hiện tại là 90: lợi nhuận 40, hiệu quả lợi nhuận/km 30, độ gần điểm đón 20. 10 điểm dành cho nhu cầu điểm đến sẽ chỉ được bổ sung khi có dữ liệu lịch sử thật; bản đầu không tự cộng điểm phỏng đoán.

## Build APK bằng GitHub Actions trên điện thoại

1. Tải ZIP mã nguồn này về điện thoại Android và giải nén.
2. Tạo repository GitHub mới, tải toàn bộ nội dung thư mục `IndriveFloatingAssist` lên repository (bao gồm thư mục ẩn `.github`).
3. Mở tab **Actions**, chọn **Build Android APK**, nhấn **Run workflow**.
4. Chờ workflow hoàn tất màu xanh. Mở lần chạy đó → **Artifacts** → tải `nha-trang-ride-assist-debug`.
5. Giải nén artifact và cài `app-debug.apk`. Nếu Android hỏi, cho phép cài ứng dụng từ nguồn này.

Workflow dùng JDK 17, Android SDK 35 và Gradle 8.9 trên máy chủ GitHub. Đây là APK debug để thử nghiệm, chưa phải bản phát hành Play Store.

## Cấp quyền và chạy

1. Mở app, cấp quyền **Vị trí** nếu muốn hiển thị GPS.
2. Cấp quyền **Hiển thị trên ứng dụng khác**.
3. Mở **Bật quyền đọc nội dung màn hình** → trong Cài đặt Trợ năng chọn **Trợ lý lọc cuốc** → bật và xác nhận.
4. Quay lại app, chọn **Bật cửa sổ nổi**.
5. Mở Grab Driver hoặc inDrive Driver. Khi giao diện có giá và khoảng cách dạng văn bản mà Android cho phép đọc, cửa sổ nổi sẽ điền dữ liệu và phân tích. Kiểm tra lại từng số trước khi dùng.

## Giới hạn quan trọng của bản đầu

- Accessibility không đọc được mọi giao diện: một số nội dung có thể được vẽ bằng đồ họa, bị ẩn hoặc không cung cấp cho dịch vụ trợ năng. Khi thiếu dữ liệu, app yêu cầu nhập/kiểm tra thủ công.
- Parser hiện nhận diện giá có đơn vị tiền và hai giá trị km hiển thị. Thứ tự hai giá trị km có thể không khớp km đón/km chở trên mọi phiên bản app; luôn xác minh các ô trước khi bấm phân tích.
- GPS hiện dùng vị trí Android và các tọa độ mốc tham chiếu tĩnh để hiển thị khu vực gần nhất. Chưa gọi Google Maps Routes API, chưa có khóa API, chưa tính lộ trình đường bộ và chưa có thống kê mật độ khách thực tế.
- Điểm nhu cầu khu vực 10 điểm đang để trống cho đến khi tích lũy dữ liệu chuyến đã xác minh.
- Chưa kiểm thử trên điện thoại thực tế hoặc tài khoản Grab/inDrive của người dùng. Cần chạy GitHub Actions, cài APK và thử từng ứng dụng để xác nhận khả năng đọc thực tế.

## Quyền riêng tư và an toàn

- Accessibility chỉ dùng để đọc nội dung đang hiển thị, không tự bấm nút hoặc gửi thao tác.
- Vị trí được đọc trên thiết bị để hiển thị mốc gần nhất; bản này không gửi tọa độ lên máy chủ.
- Không nhập mật khẩu, OTP hoặc thông tin đăng nhập vào ứng dụng.
- Đây là tiện ích độc lập, không phải ứng dụng chính thức của Grab, inDrive hay Google.

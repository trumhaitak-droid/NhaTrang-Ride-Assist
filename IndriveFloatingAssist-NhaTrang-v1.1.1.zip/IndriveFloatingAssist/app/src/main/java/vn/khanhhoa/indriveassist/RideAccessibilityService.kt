package vn.khanhhoa.indriveassist

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RideAccessibilityService : AccessibilityService() {
    private var lastText = ""
    private var lastSentAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return
        val root = rootInActiveWindow ?: return
        val parts = ArrayList<String>()
        collectText(root, parts, 0)
        val text = parts.distinct().joinToString(" · ").trim()
        if (text.length < 12 || text == lastText) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastSentAt < 900) return
        lastText = text
        lastSentAt = now
        val intent = Intent(ACTION_RIDE_SCREEN_TEXT).apply {
            setPackage(packageName)
            putExtra(EXTRA_TEXT, text.take(6000))
            putExtra(EXTRA_SOURCE_PACKAGE, event.packageName?.toString() ?: "")
        }
        sendBroadcast(intent)
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 18 || out.size > 250) return
        node.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until node.childCount) collectText(node.getChild(i), out, depth + 1)
    }

    override fun onInterrupt() = Unit

    companion object {
        const val ACTION_RIDE_SCREEN_TEXT = "vn.khanhhoa.indriveassist.RIDE_SCREEN_TEXT"
        const val EXTRA_TEXT = "screen_text"
        const val EXTRA_SOURCE_PACKAGE = "source_package"
    }
}

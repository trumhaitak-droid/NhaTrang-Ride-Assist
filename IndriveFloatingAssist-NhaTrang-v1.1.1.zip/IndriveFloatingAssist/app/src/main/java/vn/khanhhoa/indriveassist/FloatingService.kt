package vn.khanhhoa.indriveassist

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.*

class FloatingService : Service(), LocationListener {
    private lateinit var wm: WindowManager
    private lateinit var locationManager: LocationManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private val money = NumberFormat.getNumberInstance(Locale("vi", "VN"))
    private var resultView: TextView? = null
    private var screenView: TextView? = null
    private var gpsView: TextView? = null
    private var fareInput: EditText? = null
    private var pickupInput: EditText? = null
    private var tripInput: EditText? = null
    private var lastLocation: Location? = null
    private var receiverRegistered = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != RideAccessibilityService.ACTION_RIDE_SCREEN_TEXT) return
            val raw = intent.getStringExtra(RideAccessibilityService.EXTRA_TEXT).orEmpty()
            val source = intent.getStringExtra(RideAccessibilityService.EXTRA_SOURCE_PACKAGE).orEmpty()
            if (source == packageName || raw.length < 12) return
            val hasRideHints = raw.contains("km", true) || raw.contains("đ", true) || raw.contains("₫") || raw.contains("VND", true)
            if (!hasRideHints) return
            val candidate = RideTextParser.parse(raw, source)
            candidate.fare?.let { fareInput?.setText(it.toString()) }
            candidate.pickupKm?.let { pickupInput?.setText(it.toString()) }
            candidate.tripKm?.let { tripInput?.setText(it.toString()) }
            screenView?.text = "Đã đọc từ ${candidate.sourceApp}: ${candidate.confidence}. Kiểm tra các ô số liệu trước khi dùng."
            if (candidate.fare != null && candidate.pickupKm != null && candidate.tripKm != null) {
                showDecision(RideScoring.analyze(candidate))
            } else {
                resultView?.text = "CHƯA ĐỦ DỮ LIỆU — kiểm tra hoặc nhập bổ sung giá, km đón và km chở. Không tự suy đoán."
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
        registerScreenReceiver()
        startLocation()
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("ride_assist", "Trợ lý lọc cuốc", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "ride_assist")
            .setContentTitle("Trợ lý lọc cuốc đang chạy").setContentText("Chỉ phân tích và đề xuất, không tự nhận cuốc").setSmallIcon(android.R.drawable.ic_menu_compass).build()
        else @Suppress("DEPRECATION") Notification.Builder(this).setContentTitle("Trợ lý lọc cuốc đang chạy").setContentText("Cửa sổ nổi đang bật").setSmallIcon(android.R.drawable.ic_menu_compass).build()
        startForeground(41, n)
    }

    @Suppress("DEPRECATION")
    private fun registerScreenReceiver() {
        val filter = IntentFilter(RideAccessibilityService.ACTION_RIDE_SCREEN_TEXT)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, filter)
        }
        receiverRegistered = true
    }

    @Suppress("MissingPermission")
    private fun startLocation() {
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            gpsView?.text = "GPS: chưa cấp quyền vị trí trong Android"
            return
        }
        try {
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            providers.filter { locationManager.isProviderEnabled(it) }.forEach { provider ->
                locationManager.getLastKnownLocation(provider)?.let { onLocationChanged(it) }
                locationManager.requestLocationUpdates(provider, 15000L, 100f, this)
            }
        } catch (_: Exception) {
            gpsView?.text = "GPS: chưa lấy được vị trí; kiểm tra quyền và dịch vụ vị trí"
        }
    }

    private data class Zone(val name: String, val lat: Double, val lon: Double)
    private val zones = listOf(
        Zone("Trung tâm / Quảng trường 2-4", 12.2388, 109.1967),
        Zone("Ga Nha Trang", 12.2451, 109.1907),
        Zone("Chợ Đầm", 12.2527, 109.1902),
        Zone("Vĩnh Hải", 12.2730, 109.2010),
        Zone("Khu Trần Phú", 12.2250, 109.2020)
    )


    override fun onLocationChanged(location: Location) {
        lastLocation = location
        val nearest = zones.minByOrNull { distanceKm(location.latitude, location.longitude, it.lat, it.lon) }
        val zoneText = nearest?.let { " · gần ${it.name} (${"%.1f".format(Locale.US, distanceKm(location.latitude, location.longitude, it.lat, it.lon))} km)" }.orEmpty()
        gpsView?.text = "GPS ${"%.5f".format(Locale.US, location.latitude)}, ${"%.5f".format(Locale.US, location.longitude)}$zoneText"
    }

    private fun distanceKm(aLat: Double, aLon: Double, bLat: Double, bLon: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(bLat - aLat); val dLon = Math.toRadians(bLon - aLon)
        val x = sin(dLat / 2).pow(2.0) + cos(Math.toRadians(aLat)) * cos(Math.toRadians(bLat)) * sin(dLon / 2).pow(2.0)
        return 2 * r * asin(sqrt(x))
    }

    private fun showPanel() {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(248, 251, 249))
            elevation = dp(10).toFloat()
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "TRỢ LÝ LỌC CUỐC · NHA TRANG"; textSize = 14f; setTextColor(Color.rgb(18,107,80)); setPadding(0,0,dp(6),0) }
        val close = Button(this).apply { text = "Tắt"; setOnClickListener { stopSelf() } }
        header.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f)); header.addView(close, LinearLayout.LayoutParams(dp(58), dp(44)))
        card.addView(header)
        screenView = TextView(this).apply { text = "Đang chờ dữ liệu cuốc từ màn hình…"; textSize = 11f; setTextColor(Color.DKGRAY); setPadding(0,dp(4),0,dp(6)) }
        card.addView(screenView)
        gpsView = TextView(this).apply { text = "GPS: đang khởi tạo…"; textSize = 10f; setTextColor(Color.GRAY); setPadding(0,0,0,dp(6)) }
        card.addView(gpsView)
        card.addView(TextView(this).apply { text = "Sàn 80.000đ · 3.500đ/km · đón ≤ 5 km · chuyến ≥ 3 km"; textSize = 11f; setTextColor(Color.DKGRAY) })
        fareInput = field("Giá cuốc (đ)", "")
        pickupInput = field("Km đến điểm đón", "")
        tripInput = field("Km chở khách", "")
        card.addView(fareInput)
        card.addView(pickupInput)
        card.addView(tripInput)
        resultView = TextView(this).apply { text = "Chờ đọc cuốc hoặc nhập số liệu để phân tích."; textSize = 13f; setTextColor(Color.BLACK); setPadding(0,dp(8),0,dp(8)) }
        card.addView(Button(this).apply {
            text = "PHÂN TÍCH / KIỂM TRA CUỐC"
            setOnClickListener {
                val fare = fareInput?.text?.toString()?.replace(".", "")?.replace(",", "")?.toLongOrNull()
                val pickup = pickupInput?.text?.toString()?.replace(',', '.')?.toDoubleOrNull()
                val trip = tripInput?.text?.toString()?.replace(',', '.')?.toDoubleOrNull()
                val candidate = RideCandidate(fare, pickup, trip, confidence = "NHẬP / XÁC NHẬN THỦ CÔNG")
                showDecision(RideScoring.analyze(candidate))
            }
        })
        card.addView(resultView)
        card.addView(TextView(this).apply { text = "Kéo thanh tiêu đề để di chuyển. Chỉ đề xuất, không tự nhận. Số đọc tự động có thể sai — luôn đối chiếu màn hình gốc."; textSize = 10f; setTextColor(Color.GRAY) })
        val scroll = ScrollView(this).apply { addView(card) }
        params = WindowManager.LayoutParams(dp(310), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = dp(8); y = dp(90) }
        panel = scroll
        wm.addView(scroll, params)
        header.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var wx=0; var wy=0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; wx=params.x; wy=params.y; return true }
                    MotionEvent.ACTION_MOVE -> { params.x=(wx-(e.rawX-sx).toInt()).coerceAtLeast(0); params.y=(wy+(e.rawY-sy).toInt()).coerceAtLeast(0); wm.updateViewLayout(scroll, params); return true }
                }; return false
            }
        })
    }

    private fun showDecision(d: RideDecision) {
        resultView?.text = buildString {
            append(d.title)
            d.score?.let { append(" · ${d.score}/90") }
            append("\n${d.detail}")
        }
        resultView?.setTextColor(when {
            d.title.contains("ƯU TIÊN") -> Color.rgb(0, 115, 67)
            d.title.contains("BỎ QUA") -> Color.rgb(180, 35, 24)
            else -> Color.rgb(138, 90, 0)
        })
    }

    private fun field(label: String, initial: String): EditText {
        return EditText(this).apply {
            hint = label; setText(initial); textSize = 13f; singleLine = true; setPadding(8,2,8,2)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
    }

    override fun onProviderEnabled(provider: String) = Unit
    override fun onProviderDisabled(provider: String) { gpsView?.text = "GPS: nhà cung cấp vị trí đã tắt" }
    @Deprecated("Deprecated in Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit

    override fun onDestroy() {
        try { if (::locationManager.isInitialized) locationManager.removeUpdates(this) } catch (_: Exception) {}
        if (receiverRegistered) try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

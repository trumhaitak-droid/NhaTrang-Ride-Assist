package vn.khanhhoa.indriveassist

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

/** Conservative screen parser: values are suggestions and must be checked by the driver. */
data class RideCandidate(
    val fare: Long? = null,
    val pickupKm: Double? = null,
    val tripKm: Double? = null,
    val rawText: String = "",
    val sourceApp: String = "Ứng dụng khác",
    val confidence: String = "THẤP"
)

data class RideDecision(
    val title: String,
    val score: Int?,
    val cost: Long?,
    val target: Long?,
    val profit: Long?,
    val detail: String
)

object RideTextParser {
    private val currencyRegex = Regex("(?i)(\\d{1,3}(?:[.,]\\d{3})+|\\d{5,7})\\s*(?:đ|₫|vnd)")
    private val kmRegex = Regex("(?i)(\\d+(?:[.,]\\d+)?)\\s*km\\b")

    fun parse(text: String, packageName: String): RideCandidate {
        val fare = currencyRegex.findAll(text).mapNotNull { match ->
            match.groupValues[1].replace(".", "").replace(",", "").toLongOrNull()
        }.firstOrNull { it in 10000L..10000000L }
        val kms = kmRegex.findAll(text).mapNotNull {
            it.groupValues[1].replace(',', '.').toDoubleOrNull()
        }.filter { it in 0.0..1000.0 }.toList()
        val app = when {
            packageName.contains("grab", true) -> "Grab"
            packageName.contains("indrive", true) -> "inDrive"
            else -> "Ứng dụng khác"
        }
        // We only auto-fill distances when two distinct km values are visible.
        val pickup = if (kms.size >= 2) kms.first() else null
        val trip = if (kms.size >= 2) kms.last() else null
        val hasFare = fare != null
        val hasRoute = pickup != null && trip != null
        val confidence = when {
            hasFare && hasRoute -> "TRUNG BÌNH · CẦN KIỂM TRA"
            hasFare || kms.isNotEmpty() -> "THẤP · THIẾU DỮ LIỆU"
            else -> "KHÔNG ĐỦ DỮ LIỆU"
        }
        return RideCandidate(fare, pickup, trip, text.take(1200), app, confidence)
    }
}

object RideScoring {
    const val MIN_FARE = 80000L
    const val COST_PER_KM = 3500.0
    const val MAX_PICKUP_KM = 5.0
    const val MIN_TRIP_KM = 3.0
    private val money = NumberFormat.getNumberInstance(Locale("vi", "VN"))

    fun analyze(ride: RideCandidate): RideDecision {
        val fare = ride.fare
        val pickup = ride.pickupKm
        val trip = ride.tripKm
        if (fare == null || pickup == null || trip == null) {
            return RideDecision("CẦN KIỂM TRA THỦ CÔNG", null, null, null, null,
                "Chưa đọc đủ giá + km đón + km chở. Không tự suy đoán số liệu. ${ride.confidence}")
        }
        if (pickup > MAX_PICKUP_KM) return RideDecision("BỎ QUA", 0, null, null, null, "Điểm đón ${pickup} km, vượt giới hạn 5 km.")
        if (trip < MIN_TRIP_KM) return RideDecision("BỎ QUA / KIỂM TRA", 0, null, null, null, "Quãng đường chở khách dưới 3 km theo cấu hình ban đầu.")
        if (fare < MIN_FARE) return RideDecision("BỎ QUA / TRẢ GIÁ", 0, null, null, null, "Giá ${money.format(fare)}đ thấp hơn giá sàn 80.000đ.")

        val totalKm = pickup + trip
        val cost = (COST_PER_KM * totalKm).toLong()
        val target = ceil(max(MIN_FARE.toDouble(), cost / 0.8) / 5000.0).toLong() * 5000L
        val profit = fare - cost
        val margin = if (fare > 0) profit.toDouble() / fare else 0.0
        val profitScore = (margin.coerceIn(0.0, 0.45) / 0.45 * 40).toInt()
        val perKmScore = ((profit.toDouble() / totalKm).coerceIn(0.0, 12000.0) / 12000.0 * 30).toInt()
        val pickupScore = when {
            pickup <= 1.0 -> 20
            pickup <= 2.0 -> 17
            pickup <= 3.0 -> 13
            pickup <= 4.0 -> 8
            else -> 4
        }
        // The last 10 points are reserved for destination/next-trip demand data;
        // until there is real local history, do not award speculative points.
        val score = (profitScore + perKmScore + pickupScore).coerceIn(0, 90)
        val title = when {
            fare >= target && score >= 65 -> "ƯU TIÊN NHẬN"
            score >= 45 -> "CÂN NHẮC"
            else -> "BỎ QUA / TRẢ GIÁ"
        }
        val detail = "Điểm $score/90 (10 điểm nhu cầu khu vực chưa chấm vì chưa có dữ liệu lịch sử). " +
            "Chi phí ước tính ${money.format(cost)}đ; lãi ${money.format(profit)}đ; giá mục tiêu ${money.format(target)}đ. " +
            "Chưa gồm phí nền tảng, cầu đường, chờ và chiều về rỗng. Kiểm tra lại số liệu trên ứng dụng trước khi quyết định."
        return RideDecision(title, score, cost, target, profit, detail)
    }
}

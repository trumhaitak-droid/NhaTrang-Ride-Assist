package vn.khanhhoa.indriveassist

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFFF7F9F8.toInt())
        }
        root.addView(TextView(this).apply {
            text = "TRỢ LÝ LỌC CUỐC · NHA TRANG"
            textSize = 22f; setTextColor(0xFF126B50.toInt())
        }, match())
        root.addView(TextView(this).apply {
            text = "Grab + inDrive · Giá sàn 80.000đ · 3.500đ/km · đón tối đa 5 km · chuyến tối thiểu 3 km\n\nỨng dụng đọc chữ có thể truy cập trên màn hình, tính điểm và chỉ đề xuất. Không tự bấm nhận cuốc."
            textSize = 15f; setPadding(0, pad, 0, pad)
        }, match())
        root.addView(Button(this).apply {
            text = "1. Cấp quyền cửa sổ nổi"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                else startFloating()
            }
        }, match())
        root.addView(Button(this).apply {
            text = "2. Bật quyền đọc nội dung màn hình"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, match())
        root.addView(Button(this).apply {
            text = "3. Bật cửa sổ nổi"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) startFloating()
                else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }, match())
        root.addView(TextView(this).apply {
            text = "GPS: ứng dụng sẽ xin quyền vị trí khi bật trợ lý. Hiện bản đầu dùng vị trí Android và các mốc tham chiếu Nha Trang; chưa gọi Google Routes API và chưa có dữ liệu mật độ cuốc thực tế. Dữ liệu đọc từ màn hình có thể thiếu hoặc sai, hãy kiểm tra trước khi quyết định."
            textSize = 13f; setPadding(0, pad, 0, 0); setTextColor(0xFF555555.toInt())
        }, match())
        setContentView(root)
        requestLocationIfNeeded()
    }

    private fun requestLocationIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 12)
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 13)
        }
    }

    private fun startFloating() {
        val serviceIntent = Intent(this, FloatingService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
    }

    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = (10 * resources.displayMetrics.density).toInt()
    }
}

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "vn.khanhhoa.indriveassist"
    compileSdk = 35

    defaultConfig {
        applicationId = "vn.khanhhoa.indriveassist"
        minSdk = 26
        targetSdk = 33
        versionCode = 3
        versionName = "1.1.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
